# gc-leaver
Leaves Discord Group Chats (gcs) In A Quick And Easy Way
```py
# Installation 
pip install os
pip install discord
```
```py
# Usage
python leaver.py
# The Only Thing Else You Will Need Is Your Discord Token
# You Have An Option To Leave Groups With A Certain Name Or All The Group Chats Your In
```
